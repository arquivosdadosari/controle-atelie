import flet as ft
from datetime import datetime
from supabase import create_client, Client

# === CONEXÃO COM O SUPABASE NA NUVEM ===
SUPABASE_URL = "https://xbndzxkrfnguaziwlfnn.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhibmR4emtyZm5ndWF6aXdsZm5uIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQwNjMwMTcsImV4cCI6MjA5OTYzOTAxN30.j9Vhk24_uRc2Dbziu3E3xqoyuwTPYaxQpKg83S6cfCY"

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

# === INTERFACE GERAL (ESTILO CELULAR) ===
def main(page: ft.Page):
    page.title = "Controle do Ateliê"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.scroll = "auto"
    
    # Variáveis de Estado para o Dashboard
    faturamento_txt = ft.Text("R$ 0,00", size=28, weight="bold", color="green")
    despesas_txt = ft.Text("R$ 0,00", size=28, weight="bold", color="red")
    saldo_txt = ft.Text("R$ 0,00", size=28, weight="bold", color="blue")

    meses_opcoes = [
        {"key": "01", "text": "Janeiro"},
        {"key": "02", "text": "Fevereiro"},
        {"key": "03", "text": "Março"},
        {"key": "04", "text": "Abril"},
        {"key": "05", "text": "Maio"},
        {"key": "06", "text": "Junho"},
        {"key": "07", "text": "Julho"},
        {"key": "08", "text": "Agosto"},
        {"key": "09", "text": "Setembro"},
        {"key": "10", "text": "Outubro"},
        {"key": "11", "text": "Novembro"},
        {"key": "12", "text": "Dezembro"},
    ]

    mes_atual_str = datetime.now().strftime("%m")
    ano_atual_str = datetime.now().strftime("%Y")

    dropdown_mes = ft.Dropdown(
        value=mes_atual_str,
        options=[ft.dropdown.Option(key=m["key"], text=m["text"]) for m in meses_opcoes],
        width=350,
        height=65,
        text_size=18,
        focused_bgcolor="#FFF9C4",
        border_color="#FF9800",
        border_width=2,
        on_change=lambda e: atualizar_valores()
    )

    # --- FUNÇÃO PARA ATUALIZAR OS VALORES DO DASHBOARD ---
    def atualizar_valores(e=None):
        mes_selecionado = dropdown_mes.value
        data_inicio = f"{ano_atual_str}-{mes_selecionado}-01"
        # Define o último dia do mês de forma simples para o filtro
        data_fim = f"{ano_atual_str}-{mes_selecionado}-31"

        try:
            # Busca faturamento do mês
            res_servicos = supabase.table("servicos").select("valor").gte("data_servico", data_inicio).lte("data_servico", data_fim).execute()
            faturamento = sum(item["valor"] for item in res_servicos.data) if res_servicos.data else 0.0
            
            # Busca despesas do mês
            res_despesas = supabase.table("despesas").select("valor").gte("data_despesa", data_inicio).lte("data_despesa", data_fim).execute()
            despesas = sum(item["valor"] for item in res_despesas.data) if res_despesas.data else 0.0
            
            saldo = faturamento - despesas
            
            faturamento_txt.value = f"R$ {faturamento:.2f}"
            despesas_txt.value = f"R$ {despesas:.2f}"
            saldo_txt.value = f"R$ {saldo:.2f}"
        except Exception as err:
            print("Erro ao atualizar dashboard:", err)
        
        page.update()

    # --- TELA 1: INÍCIO (DASHBOARD) ---
    def view_inicio():
        return ft.Column(
            controls=[
                ft.Text("Resumo do Caixa", size=24, weight="bold"),
                ft.Container(
                    content=ft.Column([
                        ft.Text("📅  ESCOLHA O MÊS DE TRABALHO:", size=14, weight="bold", color="#E65100"),
                        dropdown_mes
                    ]),
                    padding=10,
                    alignment=ft.alignment.center
                ),
                ft.Container(
                    content=ft.Column([
                        ft.Text("Faturamento (Entradas)", size=16, color="green"),
                        faturamento_txt
                    ]),
                    bgcolor="#E8F5E9", padding=20, border_radius=15, width=350
                ),
                ft.Container(
                    content=ft.Column([
                        ft.Text("Despesas (Saídas)", size=16, color="red"),
                        despesas_txt
                    ]),
                    bgcolor="#FFEBEE", padding=20, border_radius=15, width=350
                ),
                ft.Container(
                    content=ft.Column([
                        ft.Text("Saldo (Sobrou)", size=16, color="blue"),
                        saldo_txt
                    ]),
                    bgcolor="#E3F2FD", padding=20, border_radius=15, width=350
                ),
                ft.ElevatedButton(
                    text="🔄  ATUALIZAR VALORES",
                    color="white",
                    bgcolor="#2196F3",
                    height=60,
                    width=350,
                    on_click=atualizar_valores
                )
            ],
            horizontal_alignment="center",
            spacing=10
        )

    # --- TELA 2: CLIENTES (Cadastro + Listagem Integrada) ---
    def view_clientes():
        nome_input = ft.TextField(label="Nome da Cliente", text_size=18, height=65)
        tel_input = ft.TextField(label="Telefone", text_size=18, height=65, keyboard_type=ft.KeyboardType.PHONE)
        medidas_input = ft.TextField(label="Medidas (Anotações)", text_size=16, multiline=True, min_lines=3, max_lines=4)

        lista_clientes_container = ft.Column(spacing=10)

        def excluir_cliente(id_cli):
            try:
                # Verifica antes se tem serviços vinculados
                res = supabase.table("servicos").select("id").eq("cliente_id", id_cli).execute()
                if res.data:
                    page.snack_bar = ft.SnackBar(
                        ft.Text("Não é possível excluir! Esta cliente possui trabalhos registrados.")
                    )
                    page.snack_bar.open = True
                    page.update()
                    return

                supabase.table("clientes").delete().eq("id", id_cli).execute()
                carregar_lista_clientes()
            except Exception as err:
                print("Erro ao excluir cliente:", err)

        def carregar_lista_clientes():
            lista_clientes_container.controls.clear()
            try:
                res = supabase.table("clientes").select("*").order("nome", desc=False).execute()
                dados = res.data
            except Exception as err:
                print("Erro ao carregar clientes:", err)
                dados = []

            if not dados:
                lista_clientes_container.controls.append(
                    ft.Text("Nenhuma cliente cadastrada ainda.", italic=True, size=14, color="#777777")
                )
            else:
                for row in dados:
                    id_c = row["id"]
                    nome = row["nome"]
                    tel = row["telefone"]
                    med = row["medidas"]
                    telefone_exibido = tel if tel else "Não informado"
                    medidas_exibidas = med if med else "Nenhuma anotação"
                    
                    card_item = ft.Container(
                        content=ft.Row([
                            ft.Column([
                                ft.Text(f"👤 {nome}", weight="bold", size=16, color="#1B5E20"),
                                ft.Text(f"📞 Tel: {telefone_exibido}", size=14),
                                ft.Text(f"📏 Medidas:\n{medidas_exibidas}", size=13, color="#555555", italic=True)
                            ], expand=True),
                            ft.IconButton(
                                icon=ft.icons.DELETE,
                                icon_color="red",
                                tooltip="Excluir Cliente",
                                on_click=lambda e, id_cl=id_c: excluir_cliente(id_cl)
                            )
                        ]),
                        bgcolor="#E8F5E9",
                        padding=12,
                        border_radius=8,
                        width=350
                    )
                    lista_clientes_container.controls.append(card_item)
            page.update()

        def salvar_cliente(e):
            if not nome_input.value:
                page.snack_bar = ft.SnackBar(ft.Text("O nome é obrigatório!"))
                page.snack_bar.open = True
                page.update()
                return
            
            try:
                supabase.table("clientes").insert({
                    "nome": nome_input.value,
                    "telefone": tel_input.value,
                    "medidas": medidas_input.value
                }).execute()
                
                nome_input.value = ""
                tel_input.value = ""
                medidas_input.value = ""
                page.snack_bar = ft.SnackBar(ft.Text("Cliente cadastrada com sucesso! ✅"))
                page.snack_bar.open = True
                
                carregar_lista_clientes()
                atualizar_valores()
            except Exception as err:
                print("Erro ao salvar cliente:", err)

        carregar_lista_clientes()

        return ft.Column(
            controls=[
                ft.Text("Cadastrar Cliente", size=24, weight="bold"),
                nome_input,
                tel_input,
                medidas_input,
                ft.ElevatedButton(
                    text="💾  SALVAR CLIENTE",
                    color="white",
                    bgcolor="#4CAF50",
                    height=60,
                    width=350,
                    on_click=salvar_cliente
                ),
                ft.Divider(height=20, color="#CCCCCC"),
                ft.Text("📋 Clientes Cadastradas:", size=18, weight="bold"),
                lista_clientes_container
            ],
            horizontal_alignment="center",
            spacing=15
        )

    # --- TELA 3: SERVIÇOS (Faturamento + Listagem integrada) ---
    def view_servicos():
        try:
            res_clientes = supabase.table("clientes").select("id, nome").order("nome", desc=False).execute()
            clientes = res_clientes.data or []
        except Exception as err:
            print("Erro ao carregar dropdown de clientes:", err)
            clientes = []

        opcoes_clientes = [ft.dropdown.Option(key=str(c["id"]), text=c["nome"]) for c in clientes]
        
        dropdown_cliente = ft.Dropdown(
            label="Escolha a Cliente",
            options=opcoes_clientes,
            height=65,
            text_size=18
        )
        desc_input = ft.TextField(label="O que foi feito? (Ex: Ajuste de saia)", text_size=18, height=65)
        valor_input = ft.TextField(label="Valor (R$)", text_size=18, height=65, keyboard_type=ft.KeyboardType.NUMBER)
        pago_checkbox = ft.Checkbox(label="O pagamento já foi feito?", value=False, label_style=ft.TextStyle(size=16, weight="bold"))

        lista_servicos_container = ft.Column(spacing=10)

        def excluir_servico(id_servico):
            try:
                supabase.table("servicos").delete().eq("id", id_servico).execute()
                carregar_lista_servicos()
                atualizar_valores()
            except Exception as err:
                print("Erro ao excluir serviço:", err)

        def carregar_lista_servicos():
            lista_servicos_container.controls.clear()
            
            mes_sel = dropdown_mes.value
            data_inicio = f"{ano_atual_str}-{mes_sel}-01"
            data_fim = f"{ano_atual_str}-{mes_sel}-31"
            
            try:
                # Busca trazendo o nome do cliente associado (JOIN)
                res = supabase.table("servicos").select("id, descricao, valor, pago, clientes(nome)").gte("data_servico", data_inicio).lte("data_servico", data_fim).order("id", desc=True).execute()
                dados = res.data or []
            except Exception as err:
                print("Erro ao listar serviços:", err)
                dados = []

            if not dados:
                lista_servicos_container.controls.append(
                    ft.Text("Nenhum trabalho registrado neste mês.", italic=True, size=14, color="#777777")
                )
            else:
                for row in dados:
                    id_s = row["id"]
                    desc = row["descricao"]
                    valor = row["valor"]
                    pago = row["pago"]
                    cli_nome = row["clientes"]["nome"] if row.get("clientes") else "Sem Cliente"
                    
                    status_emoji = "✅ Pago" if pago else "❌ Pendente"
                    
                    card_item = ft.Container(
                        content=ft.Row([
                            ft.Column([
                                ft.Text(f"{cli_nome}", weight="bold", size=16),
                                ft.Text(f"{desc} - R$ {valor:.2f}", size=14),
                                ft.Text(status_emoji, size=12, color="green" if pago else "orange")
                            ], expand=True),
                            ft.IconButton(
                                icon=ft.icons.DELETE,
                                icon_color="red",
                                tooltip="Excluir Lançamento",
                                on_click=lambda e, id_serv=id_s: excluir_servico(id_serv)
                            )
                        ]),
                        bgcolor="#F0F0F0",
                        padding=12,
                        border_radius=8,
                        width=350
                    )
                    lista_servicos_container.controls.append(card_item)
            page.update()

        def salvar_servico(e):
            if not dropdown_cliente.value or not desc_input.value or not valor_input.value:
                page.snack_bar = ft.SnackBar(ft.Text("Preencha todos os campos do serviço!"))
                page.snack_bar.open = True
                page.update()
                return
            
            try:
                valor = float(valor_input.value.replace(",", "."))
            except ValueError:
                page.snack_bar = ft.SnackBar(ft.Text("Valor digitado inválido!"))
                page.snack_bar.open = True
                page.update()
                return

            pago_status = True if pago_checkbox.value else False
            mes_sel = dropdown_mes.value
            data_servico = f"{ano_atual_str}-{mes_sel}-01"

            try:
                supabase.table("servicos").insert({
                    "cliente_id": int(dropdown_cliente.value),
                    "descricao": desc_input.value,
                    "valor": valor,
                    "data_servico": data_servico,
                    "pago": pago_status
                }).execute()

                dropdown_cliente.value = None
                desc_input.value = ""
                valor_input.value = ""
                pago_checkbox.value = False
                page.snack_bar = ft.SnackBar(ft.Text("Trabalho registrado com sucesso! 💰"))
                page.snack_bar.open = True
                
                carregar_lista_servicos()
                atualizar_valores()
            except Exception as err:
                print("Erro ao salvar serviço:", err)

        carregar_lista_servicos()

        return ft.Column(
            controls=[
                ft.Text("Registrar Trabalho", size=24, weight="bold"),
                dropdown_cliente,
                desc_input,
                valor_input,
                pago_checkbox,
                ft.ElevatedButton(
                    text="💰  SALVAR TRABALHO",
                    color="white",
                    bgcolor="#4CAF50",
                    height=60,
                    width=350,
                    on_click=salvar_servico  # <--- CORRIGIDO AQUI!
                ),
                ft.Divider(height=20, color="#CCCCCC"),
                ft.Text("📋 Trabalhos Lançados (Este Mês):", size=18, weight="bold"),
                lista_servicos_container
            ],
            horizontal_alignment="center",
            spacing=15
        )

    # --- TELA 4: DESPESAS (Gastos + Listagem integrada) ---
    def view_despesas():
        desc_input = ft.TextField(label="O que comprou? (Ex: Agulhas)", text_size=18, height=65)
        valor_input = ft.TextField(label="Valor Pago (R$)", text_size=18, height=65, keyboard_type=ft.KeyboardType.NUMBER)
        categoria_dropdown = ft.Dropdown(
            label="Categoria",
            options=[
                ft.dropdown.Option("Tecidos"),
                ft.dropdown.Option("Linhas/Aviamentos"),
                ft.dropdown.Option("Manutenção"),
                ft.dropdown.Option("Outros")
            ],
            height=65,
            text_size=18
        )

        lista_despesas_container = ft.Column(spacing=10)

        def excluir_despesa(id_desp):
            try:
                supabase.table("despesas").delete().eq("id", id_desp).execute()
                carregar_lista_despesas()
                atualizar_valores()
            except Exception as err:
                print("Erro ao excluir despesa:", err)

        def carregar_lista_despesas():
            lista_despesas_container.controls.clear()
            
            mes_sel = dropdown_mes.value
            data_inicio = f"{ano_atual_str}-{mes_sel}-01"
            data_fim = f"{ano_atual_str}-{mes_sel}-31"
            
            try:
                res = supabase.table("despesas").select("*").gte("data_despesa", data_inicio).lte("data_despesa", data_fim).order("id", desc=True).execute()
                dados = res.data or []
            except Exception as err:
                print("Erro ao listar despesas:", err)
                dados = []

            if not dados:
                lista_despesas_container.controls.append(
                    ft.Text("Nenhuma despesa registrada neste mês.", italic=True, size=14, color="#777777")
                )
            else:
                for row in dados:
                    id_d = row["id"]
                    desc = row["descricao"]
                    valor = row["valor"]
                    cat = row["categoria"]
                    
                    card_item = ft.Container(
                        content=ft.Row([
                            ft.Column([
                                ft.Text(f"{desc}", weight="bold", size=16),
                                ft.Text(f"R$ {valor:.2f} ({cat})", size=14, color="#555555")
                            ], expand=True),
                            ft.IconButton(
                                icon=ft.icons.DELETE,
                                icon_color="red",
                                tooltip="Excluir Despesa",
                                on_click=lambda e, id_ds=id_d: excluir_despesa(id_ds)
                            )
                        ]),
                        bgcolor="#FFF3F3",
                        padding=12,
                        border_radius=8,
                        width=350
                    )
                    lista_despesas_container.controls.append(card_item)
            page.update()

        def salvar_despesa(e):
            if not desc_input.value or not valor_input.value:
                page.snack_bar = ft.SnackBar(ft.Text("Preencha os campos da despesa!"))
                page.snack_bar.open = True
                page.update()
                return

            try:
                valor = float(valor_input.value.replace(",", "."))
            except ValueError:
                page.snack_bar = ft.SnackBar(ft.Text("Valor digitado inválido!"))
                page.snack_bar.open = True
                page.update()
                return

            mes_sel = dropdown_mes.value
            data_despesa = f"{ano_atual_str}-{mes_sel}-01"
            categoria = categoria_dropdown.value or "Outros"

            try:
                supabase.table("despesas").insert({
                    "descricao": desc_input.value,
                    "valor": valor,
                    "data_despesa": data_despesa,
                    "categoria": categoria
                }).execute()

                desc_input.value = ""
                valor_input.value = ""
                categoria_dropdown.value = "Tecidos"
                page.snack_bar = ft.SnackBar(ft.Text("Despesa anotada com sucesso! 💸"))
                page.snack_bar.open = True
                
                carregar_lista_despesas()
                atualizar_valores()
            except Exception as err:
                print("Erro ao salvar despesa:", err)

        carregar_lista_despesas()

        return ft.Column(
            controls=[
                ft.Text("Registrar Gasto", size=24, weight="bold"),
                desc_input,
                valor_input,
                categoria_dropdown,
                ft.ElevatedButton(
                    text="💸  SALVAR DESPESA",
                    color="white",
                    bgcolor="#dc3545",
                    height=60,
                    width=350,
                    on_click=salvar_despesa
                ),
                ft.Divider(height=20, color="#CCCCCC"),
                ft.Text("📋 Gastos Lançados (Este Mês):", size=18, weight="bold"),
                lista_despesas_container
            ],
            horizontal_alignment="center",
            spacing=15
        )

    # --- CONTROLADOR DE ABAS ---
    def mudar_aba(e):
        page.clean()
        if e.control.selected_index == 0:
            page.add(view_inicio())
            atualizar_valores()
        elif e.control.selected_index == 1:
            page.add(view_clientes())
        elif e.control.selected_index == 2:
            page.add(view_servicos())
        elif e.control.selected_index == 3:
            page.add(view_despesas())
        
        page.add(navigation_bar)
        page.add(
            ft.Container(
                content=ft.Text("Developed by A. Mansur", size=11, italic=True, color="#888888"),
                alignment=ft.alignment.center,
                margin=ft.margin.only(top=20, bottom=10)
            )
        )
        page.update()

    navigation_bar = ft.NavigationBar(
        destinations=[
            ft.NavigationDestination(icon=ft.icons.HOME, label="Início"),
            ft.NavigationDestination(icon=ft.icons.PERSON_ADD, label="Clientes"),
            ft.NavigationDestination(icon=ft.icons.ATTACH_MONEY, label="Trabalhos"),
            ft.NavigationDestination(icon=ft.icons.MONETIZATION_ON_OUTLINED, label="Gastos"),
        ],
        on_change=mudar_aba,
        selected_index=0
    )

    # Desenhar Tela Inicial
    page.add(view_inicio())
    page.add(navigation_bar)
    page.add(
        ft.Container(
            content=ft.Text("Developed by A. Mansur", size=11, italic=True, color="#888888"),
            alignment=ft.alignment.center,
            margin=ft.margin.only(top=20, bottom=10)
        )
    )
    atualizar_valores()

if __name__ == "__main__":
    ft.app(target=main, view=ft.AppView.WEB_BROWSER)